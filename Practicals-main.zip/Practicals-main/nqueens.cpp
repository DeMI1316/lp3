#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

class NQueens {
private:
    int n;
    vector<vector<int>> board;
    vector<vector<vector<int>>> solutions;

    bool isSafe(int row, int col) {
        // Check if there is a queen in the same row
        for (int i = 0; i < col; ++i) {
            if (board[row][i]) return false;
        }

        // Check upper diagonal on left side
        for (int i = row, j = col; i >= 0 && j >= 0; --i, --j) {
            if (board[i][j]) return false;
        }

        // Check lower diagonal on left side
        for (int i = row, j = col; i < n && j >= 0; ++i, --j) {
            if (board[i][j]) return false;
        }

        return true;
    }

    void solveBacktracking(int col) {
        if (col >= n) {
            solutions.push_back(board);
            return;
        }

        for (int i = 0; i < n; ++i) {
            if (isSafe(i, col)) {
                board[i][col] = 1;
                solveBacktracking(col + 1);
                board[i][col] = 0;
            }
        }
    }

    

public:
    NQueens(int size) : n(size), board(size, vector<int>(size, 0)) {}

    vector<vector<vector<int>>> solveNQueensBacktracking() {
        solveBacktracking(0);
        return solutions;
    }

 
};

int main() {
    int n;
    cout << "Enter the size of the chessboard (N): ";
    cin >> n;

    NQueens nQueens(n);

    cout << "Solutions using Backtracking:" << endl;
    int count = 0;
    auto solutionsBacktracking = nQueens.solveNQueensBacktracking();
    for (const auto& solution : solutionsBacktracking) {
        for (const auto& row : solution) {
            for (int val : row) {
                cout << val << " ";
            }
            cout << endl;
        }
        cout << endl;  
        count +=1 ;
    }
    cout << "No of Possible solutions are :" << count;
    
    return 0;
}

