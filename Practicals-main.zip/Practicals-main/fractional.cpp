#include <bits/stdc++.h>
using namespace std;

struct Item {
    int value;
    int weight;
    double ratio;

    Item(int v, int w) : value(v), weight(w), ratio((double)v / w) {}
};

bool compare(Item& a, Item& b) {
    return a.ratio > b.ratio;  // Sort in descending order of value-to-weight ratio
}

double fractionalKnapsack(int capacity, vector<Item>& items) {
    sort(items.begin(), items.end(), compare);
    double totalValue = 0.0;

    for (const auto& item : items) {
        if (capacity <= 0) break;
        if (item.weight <= capacity) {
            totalValue += item.value;
            capacity -= item.weight;
        } else {
            totalValue += item.ratio * capacity;  // Take the fraction of the last item
            capacity = 0;  // The knapsack is now full
        }
    }

    return totalValue;
}

int main() {
    int n, capacity;
    cout << "Enter the number of items: ";
    cin >> n;
    
    vector<Item> items;
    for (int i = 0; i < n; i++) {
        int value, weight;
        cout << "Enter value and weight for item " << i + 1 << ": ";
        cin >> value >> weight;
        items.push_back(Item(value, weight));
    }

    cout << "Enter the capacity of the knapsack: ";
    cin >> capacity;

    double maxValue = fractionalKnapsack(capacity, items);
    cout << "Maximum value in the knapsack: " << maxValue << endl;

    return 0;
}
