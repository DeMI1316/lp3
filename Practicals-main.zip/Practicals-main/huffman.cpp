#include <bits/stdc++.h>
using namespace std;

struct Node {
    char ch;
    int freq;
    Node *left, *right;
    Node(char character, int frequency) : ch(character), freq(frequency), left(nullptr), right(nullptr) {}
};

struct Compare {
    bool operator()(Node *l, Node *r) {
        return l->freq > r->freq;
    }
};

Node* buildHuffmanTree(const unordered_map<char, int>& frequency) {
    priority_queue<Node*, vector<Node*>, Compare> minHeap;
    for (const auto& pair : frequency) {
        minHeap.push(new Node(pair.first, pair.second));
    }
    while (minHeap.size() > 1) {
        Node *left = minHeap.top(); minHeap.pop();
        Node *right = minHeap.top(); minHeap.pop();
        Node *merged = new Node('\0', left->freq + right->freq);
        merged->left = left;
        merged->right = right;
        minHeap.push(merged);
    }
    return minHeap.top();
}

void generateCodes(Node* root, const string& str, unordered_map<char, string>& huffmanCodes) {
    if (!root) return;
    if (root->left == nullptr && root->right == nullptr) {
        huffmanCodes[root->ch] = str;
    }
    generateCodes(root->left, str + "0", huffmanCodes);
    generateCodes(root->right, str + "1", huffmanCodes);
}

pair<string, unordered_map<char, string>> huffmanEncoding(const string& text) {
    unordered_map<char, int> frequency;
    for (char ch : text) frequency[ch]++;
    Node* root = buildHuffmanTree(frequency);
    unordered_map<char, string> huffmanCodes;
    generateCodes(root, "", huffmanCodes);
    string encodedText;
    for (char ch : text) {
        encodedText += huffmanCodes[ch];
    }
    return make_pair(encodedText, huffmanCodes);
}

string huffmanDecoding(const string& encodedText, const unordered_map<char, string>& huffmanCodes) {
    string decodedText;
    string currentCode;
    unordered_map<string, char> reverseCodes;
    for (const auto& pair : huffmanCodes) {
        reverseCodes[pair.second] = pair.first;
    }
    for (char bit : encodedText) {
        currentCode += bit;
        if (reverseCodes.find(currentCode) != reverseCodes.end()) {
            decodedText += reverseCodes[currentCode];
            currentCode.clear();
        }
    }
    return decodedText;
}

int main() {
    string text = "hello huffman";
    cout << "Original text: " << text << endl;

    pair<string, unordered_map<char, string>> result = huffmanEncoding(text);
    string encodedText = result.first;
    unordered_map<char, string> huffmanCodes = result.second;

    cout << "Encoded text: " << encodedText << endl;
    cout << "Huffman Codes:" << endl;
    for (const auto& pair : huffmanCodes) {
        cout << pair.first << ": " << pair.second << endl;
    }

    string decodedText = huffmanDecoding(encodedText, huffmanCodes);
    cout << "Decoded text: " << decodedText << endl;

    return 0;
}
