def fibonacci_recursive(n):
    if n <= 0:
        return "Input must be a positive integer."
    elif n == 1:
        return [0]
    elif n == 2:
        return [0, 1]
    else:
        seq = fibonacci_recursive(n - 1)
        seq.append(seq[-1] + seq[-2])
        return seq

# Iterative function to calculate Fibonacci sequence
def fibonacci_iterative(n):
    if n <= 0:
        return "Input must be a positive integer."
    elif n == 1:
        return [0]
    elif n == 2:
        return [0, 1]
    else:
        seq = [0, 1]
        for _ in range(2, n):
            seq.append(seq[-1] + seq[-2])
        return seq

# User input
n = int(input("Enter the number of Fibonacci terms to print: "))

# Choose method
method = input("Choose method (recursive/iterative): ").strip().lower()

if method == "recursive":
    print(f"Fibonacci sequence up to {n} terms (recursive): {fibonacci_recursive(n)}")
elif method == "iterative":
    print(f"Fibonacci sequence up to {n} terms (iterative): {fibonacci_iterative(n)}")
else:
    print("Invalid method chosen. Please choose either 'recursive' or 'iterative'.")
